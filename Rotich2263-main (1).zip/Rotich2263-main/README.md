- 👋 Hi, I’m @Rotich
- 👀 I’m interested in coding
- 🌱 I’m currently learning coding with different languages
- 💞️ I’m looking to collaborate on programing and coding
- 📫 How to reach me through whatsapp number +254 706128824
- 😄 Pronouns: Him
- ⚡ Fun fact: I love it.

<!---
Rotich2263/Rotich2263 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
